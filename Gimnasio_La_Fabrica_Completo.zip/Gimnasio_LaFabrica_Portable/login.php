<?php
/**
 * PÁGINA DE LOGIN - GIMNASIO LA FABRICA (SQLite Embebido)
 */
require_once __DIR__ . '/includes/config.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = escapar($_POST['name'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($email) || empty($password)) {
        $error = 'Por favor completa todos los campos';
    } else {
        // Soporta buscar tanto por nombre como por correo electrónico
        $usuario = obtenerFila("SELECT * FROM users WHERE name = :u OR email = :u LIMIT 1", [':u' => $email]);
        
        if ($usuario && $password === $usuario['password']) {
            $_SESSION['usuario_id'] = (int)$usuario['id'];
            $_SESSION['usuario_nombre'] = $usuario['name'];
            $_SESSION['usuario_rol'] = $usuario['role'];
            
            actualizar('users', ['lastSignedIn' => date('Y-m-d H:i:s')], "id = " . (int)$usuario['id']);
            
            header("Location: /pages/dashboard.php");
            exit();
        } else {
            $error = 'Nombre o contraseña incorrectos';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .login-container {
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
            padding: 40px;
            max-width: 420px;
            width: 100%;
        }
        .btn-login {
            background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);
            border: none;
            color: white;
            font-weight: bold;
            padding: 12px;
            border-radius: 10px;
            width: 100%;
            transition: all 0.2s;
        }
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(79, 70, 229, 0.4);
            color: white;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="text-center mb-4">
            <div style="font-size: 2.5rem;">🏋️</div>
            <h2 class="fw-bold text-dark mt-2"><?php echo APP_NAME; ?></h2>
            <span class="badge bg-secondary-subtle text-secondary border">Acceso al Sistema</span>
        </div>
        
        <?php if ($error): ?>
            <div class="alert alert-danger py-2 small" role="alert">
                <i class="fas fa-exclamation-circle me-1"></i> <?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="" autocomplete="off">
            <div class="mb-3">
                <label for="name" class="form-label fw-bold text-muted small">Usuario o Correo:</label>
                <div class="input-group">
                    <span class="input-group-text bg-light"><i class="fas fa-user text-muted"></i></span>
                    <input type="text" class="form-control py-2" id="name" name="name" required autofocus autocomplete="username">
                </div>
            </div>
            
            <div class="mb-4">
                <label for="password" class="form-label fw-bold text-muted small">Contraseña:</label>
                <div class="input-group">
                    <span class="input-group-text bg-light"><i class="fas fa-lock text-muted"></i></span>
                    <input type="password" class="form-control py-2" id="password" name="password" required autocomplete="current-password">
                </div>
            </div>
            
            <button type="submit" class="btn btn-login">
                <i class="fas fa-sign-in-alt me-1"></i> Iniciar Sesión
            </button>
        </form>
    </div>
</body>
</html>
